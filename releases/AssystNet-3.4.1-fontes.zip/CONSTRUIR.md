# Reprodução do pacote enviado à Mozilla — versão 3.4.1

Este pacote contém as fontes legíveis e mantidas diretamente: JavaScript, HTML e CSS.
`build.py` apenas copia os nove arquivos de execução para um ZIP com metadados fixos.
Não transpila, concatena, minimiza ou gera código da extensão. Não há bibliotecas externas,
instalação de npm, dependências de produção, acesso à rede ou credenciais durante a construção.

## Sistema operacional e programas

- Windows 10/11, Linux ou macOS, com permissão para escrever na pasta extraída.
- Python **3.12 ou posterior**. Construção e reprodução verificadas em Linux com Python **3.12.14**.
- Nenhum outro programa é necessário para construir o ZIP. Node e Firefox não são requisitos de construção.

Instalação do Python:

- Windows/macOS: use o instalador oficial em https://www.python.org/downloads/. No Windows,
  uma instalação Python 3.12 com o Python Launcher permite executar `py -3.12`.
  O instalador 3.12.10 também atende ao requisito da série 3.12.
- Debian/Ubuntu com Python 3.12 disponível: `sudo apt-get update` e `sudo apt-get install python3`.
  Confira a versão; em outros sistemas use o pacote Python 3.12+ do sistema ou o instalador oficial.

## Passos completos

1. Extraia `AssystNet-3.4.1-fontes.zip` preservando todos os arquivos.
2. Abra um terminal na pasta que contém `manifest.json` e `build.py`.
3. Confira o Python e execute o único passo técnico de construção:

Linux/macOS:

```sh
python3 --version
python3 build.py
```

Windows PowerShell:

```powershell
py -3.12 --version
py -3.12 build.py
```

Se instalou uma versão mais recente no Windows, use o seletor correspondente,
por exemplo `py -3.13`, ou `python` quando configurado pelo instalador.

4. O resultado é `releases/AssystNet-3.4.1-submissao.zip`. O script imprime seu SHA-256.
5. Para conferir uma cópia do ZIP enviado, compare os bytes, usando o caminho desse arquivo:

```sh
python3 build.py --verify /caminho/AssystNet-3.4.1-submissao.zip
```

No Windows use `py -3.12 build.py --verify "C:\caminho\AssystNet-3.4.1-submissao.zip"`.
O SHA-256 de referência está em `REPRODUCAO.txt`. O ZIP usa ordem de arquivos,
datas, permissões e método de armazenamento fixos. Os bytes das fontes não são alterados.

## Validação opcional

Os testes nativos requerem Node.js 24 (testado com 24.19.0), instalável em https://nodejs.org/.
Não instalam pacotes nem participam da construção:

```sh
node --test tests/*.test.cjs
```

Validação desta entrega: 39 testes de dados/background e três testes adicionais de interface
em DOM simulado passaram. `web-ext` 10.7.0 terminou com zero erros, avisos e notificações.
Os testes adicionais usam jsdom 26.1.0 como ferramenta externa de revisão; essa ferramenta
não está incluída na extensão e não é necessária para construir ou executar o pacote.
O funcionamento na interface institucional real ainda precisa ser testado no Firefox.

## Arquivos para o portal

- `AssystNet-3.4.1-submissao.zip`: envie como a nova versão da extensão.
- `AssystNet-3.4.1-fontes.zip`: envie no campo **Enviar código-fonte** dessa mesma versão.

O ZIP de fontes inclui instruções, testes e script. O ZIP da extensão contém somente os nove
arquivos de execução na raiz. Não contém backups pessoais, dados de chamados, credenciais,
arquivos do Git, ferramentas de desenvolvimento ou versões anteriores.

Referência oficial: https://extensionworkshop.com/documentation/publish/source-code-submission/

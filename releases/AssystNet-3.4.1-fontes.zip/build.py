#!/usr/bin/env python3
"""Package the readable sources unchanged, with reproducible ZIP metadata."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = (
    'manifest.json', 'data.js', 'background.js', 'queue.js', 'content.js',
    'popup.html', 'popup.css', 'popup.js', 'detail.js',
)


def build(output):
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    assert manifest['manifest_version'] == 3
    assert manifest['browser_specific_settings']['gecko']['id'] == 'assyst-status-tagger@tjce.local'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
        for name in FILES:
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_STORED
            archive.writestr(entry, (ROOT / name).read_bytes())
    return hashlib.sha256(output.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--verify', type=Path, help='Compare the output byte for byte with the submitted ZIP.')
    args = parser.parse_args()
    version = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))['version']
    output = args.output or ROOT / 'releases' / f'AssystNet-{version}-submissao.zip'
    digest = build(output)
    if args.verify and args.verify.read_bytes() != output.read_bytes():
        raise SystemExit('Verification failed: the submitted ZIP does not match the sources.')
    print(f'Created: {output}')
    print(f'SHA256: {digest}')
    if args.verify:
        print('Verification successful: the ZIP files are byte-for-byte identical.')


if __name__ == '__main__':
    main()
